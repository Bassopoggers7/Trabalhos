WARNING : Tests must be launched for development purposes only.
Tests may change your game configuration (as an example, your saves could be deleted !).